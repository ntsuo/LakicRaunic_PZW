from django.contrib import admin
from main.models import Umjetnik, UmjetnickoDjelo, KulturniDogadaj

# Register your models here.

model_list = [Umjetnik, UmjetnickoDjelo, KulturniDogadaj]
admin.site.register(model_list)