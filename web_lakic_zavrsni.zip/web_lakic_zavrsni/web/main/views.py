from django.shortcuts import redirect, render
from django.urls import reverse_lazy
from django.views import *
from django.views.generic import *
from main.models import *
from django.views.generic.edit import UpdateView
from django.urls import reverse_lazy
from .models import *
from .forms import *
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate, login


## Create your views here.
class HomePageView(View):
    def get(self, request, *args, **kwargs):
            return render(request, 'home.html')

def landing_page(request):
    return render(request, 'home.html')

##list umjetnik
class UmjetnikListView(ListView):
    model = Umjetnik
    template_name = 'main/umjetnik.html'  
    context_object_name = 'umjetnici'

    def get_queryset(self):
        return Umjetnik.objects.all()
    

##add umjetnik
class UmjetnikCreateView(CreateView):
    model = Umjetnik
    form_class = UmjetnikForm
    template_name = 'add_umjetnik.html'
    success_url = reverse_lazy('main:umjetnici') 

##delete umjetnik
class UmjetnikDeleteView(DeleteView):
    model = Umjetnik 
    template_name = 'delete_umjetnik.html'
    success_url = reverse_lazy('main:umjetnici')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['umjetnik'] = self.get_object()
        return context
    
##update umjetnik
class UmjetnikUpdateView(UpdateView):
    model = Umjetnik
    form_class = UmjetnikForm
    template_name = 'update_umjetnik.html'
    success_url = reverse_lazy('main:umjetnici')  


##list djela
class DjelaListView(ListView):
    model = UmjetnickoDjelo
    template_name = 'main/djela_list.html'  
    context_object_name = 'djela'

    def get_queryset(self):
        return UmjetnickoDjelo.objects.all()
    

##lista pretrage djela
class PretragaListView(ListView):
    model = UmjetnickoDjelo
    template_name = 'main/djela_pretraga.html'  
    context_object_name = 'djela'

    def get_queryset(self):
        return UmjetnickoDjelo.objects.all()
    

##add djela
class DjelaCreateView(CreateView):
    model = UmjetnickoDjelo
    form_class = UmjetnikoDjeloForm
    template_name = 'add_djelo.html'
    success_url = reverse_lazy('main:djela') 

##delete djela
class DjelaDeleteView(DeleteView):
    model = UmjetnickoDjelo 
    template_name = 'delete_djelo.html'
    success_url = reverse_lazy('main:djela')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['djelo'] = self.get_object()
        return context
    
##update djela
class DjelaUpdateView(UpdateView):
    model = UmjetnickoDjelo
    form_class = UmjetnikoDjeloForm
    template_name = 'update_djelo.html'
    success_url = reverse_lazy('main:djela')  

##list dogadaj
class DogadajListView(ListView):
    model = KulturniDogadaj
    template_name = 'main/dogadaji_list.html'  
    context_object_name = 'dogadaji'

    def get_queryset(self):
        return KulturniDogadaj.objects.all()
    

##add dogadaj
class DogadajCreateView(CreateView):
    model = KulturniDogadaj
    form_class = KulturniDogadajForm
    template_name = 'add_dogadaj.html'
    success_url = reverse_lazy('main:dogadaji') 

##delete dogadaj
class DogadajDeleteView(DeleteView):
    model = KulturniDogadaj
    template_name = 'delete_dogadaj.html'
    success_url = reverse_lazy('main:dogadaji')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['dogadaj'] = self.get_object()
        return context
    
##update dogadaj
class DogadajUpdateView(UpdateView):
    model = KulturniDogadaj
    form_class = KulturniDogadajForm
    template_name = 'update_dogadaj.html'
    success_url = reverse_lazy('main:dogadaji')  

def index(request):
    return render(request, './home.html')

def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)

        if form.is_valid():
            form.save()
            username = form.cleaned_data['username']
            password = form.cleaned_data['password1']

            user = authenticate(username=username, password=password)
            login(request, user)
            return redirect('main:home')

    else:
        form = UserCreationForm()

    context = {'form': form}
    return render(request, 'registration/register.html', context)
