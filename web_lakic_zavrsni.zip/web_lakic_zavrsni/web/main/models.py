from django.db import models
from django.utils import timezone


class Umjetnik(models.Model):
    umjetnik_ime = models.CharField(max_length=100)
    biografija = models.TextField()
    slike_umjetnika = models.ManyToManyField('UmjetnickoDjelo', related_name='umjetnik_slika', blank=True)


    def __str__(self):
        return self.umjetnik_ime

class UmjetnickoDjelo(models.Model):
    naslov_djela = models.CharField(max_length=255)
    umjetnik = models.ForeignKey(Umjetnik, on_delete=models.CASCADE)
    opis_slike = models.TextField()

    def __str__(self):
        return self.naslov_djela

class KulturniDogadaj(models.Model):
    naslov_dogadaja = models.CharField(max_length=255)
    opis_dogadaja = models.TextField()
    lokacija = models.CharField(max_length=255)
    umjetnicka_djela = models.ManyToManyField(UmjetnickoDjelo)

    def __str__(self):
        return self.naslov_dogadaja
