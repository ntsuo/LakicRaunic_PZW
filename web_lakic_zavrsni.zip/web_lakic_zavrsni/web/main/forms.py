from django import forms
from .models import *

class UmjetnikForm(forms.ModelForm):
    class Meta:
        model = Umjetnik
        fields = ['umjetnik_ime', 'biografija']

class UmjetnikoDjeloForm(forms.ModelForm):
    class Meta:
        model = UmjetnickoDjelo
        fields = ['naslov_djela', 'umjetnik', 'opis_slike']

class KulturniDogadajForm(forms.ModelForm):
    class Meta:
        model = KulturniDogadaj
        fields = ['naslov_dogadaja', 'opis_dogadaja', 'lokacija', 'umjetnicka_djela']
        widgets = {
        'datum': forms.DateInput(attrs={'type': 'date'})
    }
    def __init__(self, *args, **kwargs):
        super(KulturniDogadajForm, self).__init__(*args, **kwargs)
        self.fields['umjetnicka_djela'].queryset = UmjetnickoDjelo.objects.all()
