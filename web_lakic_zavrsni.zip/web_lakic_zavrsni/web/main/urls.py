from django.urls import path
from . import views

app_name = 'main'  # here for namespacing of urls.

urlpatterns = [
    path('', views.HomePageView.as_view(), name='home'),

    path('umjetnici/', views.UmjetnikListView.as_view(), name='umjetnici'),
    path('addumjetnici/', views.UmjetnikCreateView.as_view(), name='addumjetnici'),
    path('deleteumjetnici/<int:pk>', views.UmjetnikDeleteView.as_view(), name='deleteumjetnici'),
    path('updateumjetnici/<int:pk>', views.UmjetnikUpdateView.as_view(), name='updateumjetnici'),

    path('djela/', views.DjelaListView.as_view(), name='djela'),
    path('pretraga/', views.PretragaListView.as_view(), name='pretraga'),    
    path('adddjela/', views.DjelaCreateView.as_view(), name='adddjela'),
    path('deletedjela/<int:pk>', views.DjelaDeleteView.as_view(), name='deletedjela'),
    path('updatedjela/<int:pk>', views.DjelaUpdateView.as_view(), name='updatedjela'),

    path('dogadaji/', views.DogadajListView.as_view(), name='dogadaji'),
    path('adddogadaji/', views.DogadajCreateView.as_view(), name='adddogadaji'),
    path('deletedogadaji/<int:pk>', views.DogadajDeleteView.as_view(), name='deletedogadaji'),
    path('updatedogadaji/<int:pk>', views.DogadajUpdateView.as_view(), name='updatedogadaji'),

    path('register/', views.register, name='register'),

]
