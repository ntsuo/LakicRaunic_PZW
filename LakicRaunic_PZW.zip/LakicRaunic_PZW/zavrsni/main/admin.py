from django.contrib import admin
from main.models import *

model_list= [Umjetnik, UmjetnickoDjelo, KulturniDogadaj ]
admin.site.register(model_list)