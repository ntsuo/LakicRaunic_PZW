from django.db import models
from django.contrib.auth.models import User

class Umjetnik(models.Model):
    ime = models.CharField(max_length=100)
    biografija = models.TextField(blank=True)
    slike_umjetnika = models.ManyToManyField('UmjetnickoDjelo', related_name='umjetnik_slika', blank=True)

    def __str__(self):
        return self.ime

class UmjetnickoDjelo(models.Model):
    naslov = models.CharField(max_length=255)
    umjetnik = models.ForeignKey(Umjetnik, on_delete=models.CASCADE)
    opis = models.TextField(blank=True)
    slika = models.ImageField(upload_to='umjetnicka_djela/')
    datum_stvaranja = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.naslov

class KulturniDogadaj(models.Model):
    naslov = models.CharField(max_length=255)
    opis = models.TextField()
    datum = models.DateField()
    vrijeme = models.TimeField()
    lokacija = models.CharField(max_length=255)
    kreirao = models.ForeignKey(User, on_delete=models.CASCADE)
    umjetnicka_djela = models.ManyToManyField(UmjetnickoDjelo, blank=True)

    def __str__(self):
        return self.naslov
